#include "Tosoba.h"
#include <iostream>
#include<cstring> //biblioteka lancychow z C
#include<iomanip>
using namespace std;

Tosoba::Tosoba()
{
    cout<<"Konstruktor domyslny clasy Tosoba "<<endl;
    strcpy(nazwisko, "Martyniuk");
    imie="Nadiia";
    dataur.d=26;
    dataur.m=9;
    dataur.r=2004;
}
Tosoba::Tosoba(const char*naz, const string &im, Tdata dd){
    cout<<"Konstruktor z parametrami clasy Tosoba "<<endl;
    imie=im;
    dataur=dd;
    strcpy(nazwisko, naz);
}
void Tosoba::wczytaj(){
    cout<<"Podaj imie i nazwisko ";
    cin>>imie>>nazwisko;
    cout<<"Podaj dzien urodzenia ";
    cin>>dataur.d;
    cout<<"Podaj miesiac urodzenia ";
    cin>>dataur.m;
    cout<<"Podaj rok urodzenia ";
    cin>>dataur.r;
}
void Tosoba::wyswietl(){
    cout<<nazwisko<<" "<<imie<<" ";
    cout<<setfill('0')<<setw(2)<<dataur.d<<"."<<setw(2)<<dataur.m<<"."<<dataur.r<<endl;
}
void Tosoba::wyswietl(int rok){

    if (rok>=dataur.r)
        cout<<nazwisko<<" "<<imie<<" "<<rok-dataur.r<<" lat"<<endl;
    else
        cout<<"Wystapil blad. Wprowadzono zly dane "<<endl<<"Taki czlowiek jaszcze nie urodzil sie. Zaczekaj "<<dataur.r-rok<<" lata"<<endl;

}
void Tosoba::info(){
    cout<<"Osoba ukonczyla (bedzie miala) 18 lat w "<<dataur.r+18<<" roku"<<endl;
}
void Tosoba::info(int rok){
    if (rok-dataur.r>=50)
        cout<<"Jest to osoba 50+ "<<endl;
    else if (rok-dataur.r>=30)
        cout<<"Jest to osoba 30+ "<<endl;
    else if (rok-dataur.r>=18)
        cout<<"Jest to osoba pelnoletnia "<<endl;
    else if (rok-dataur.r>=0)
        cout<<"To dziecko"<<endl;
    else
        cout<<"info o osobie bedzie dostepne, kiedy osoba urodzi sie"<<endl;

}
Tosoba::~Tosoba()
{
    cout<<"Destruktor clasy Tosoba "<<endl;
}
