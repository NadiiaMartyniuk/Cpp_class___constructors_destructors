#include <iostream>
#include "Tosoba.h"
using namespace std;

int main()
{
    int rok, rok2;
    cout<<"Jaki teraz rok ? ";
    cin>>rok;
    cout<<endl<<"OSOBA 1"<<endl;
    Tosoba osoba; // deklaracja obiektu z automatycznym wywolaniem konstruktora domyslnego
    osoba.wyswietl();
    osoba.wyswietl(rok);
    osoba.info();
    osoba.info(rok);


    cout<<endl;
    cout<<"OSOBA 2"<<endl;
    Tosoba osoba2; // deklaracja obiektu z automatycznym wywolaniem konstruktora domyslnego
    osoba2.wczytaj();
    osoba2.wyswietl();
    osoba2.wyswietl(rok);
    osoba2.info();
    osoba2.info(rok);
    cout<<endl;

    cout<<endl;
    cout<<"OSOBA 3"<<endl;
    Tosoba *wsk;
    wsk = new Tosoba("Nowak", "Ewa", {16,06,2013});
    wsk -> wyswietl();
    wsk -> info();
    wsk -> info(rok);
    cout<<endl;
    return 0;
}
