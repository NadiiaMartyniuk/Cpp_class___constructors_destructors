#ifndef TOSOBA_H
#define TOSOBA_H
using namespace std;
#include<string> //obsluga clasy string

struct Tdata{
    int d;
    int m;
    int r;
};
class Tosoba
{
    public:
        Tosoba(); //konstruktor domy�lny
        Tosoba(const char*naz, const string &im, Tdata dd);// Konstruktor z parametrami, przeciazony
        ~Tosoba(); //destructor
        void wczytaj();
        void wyswietl();
        void wyswietl(int rok);
        void info();
        void info(int rok);

    protected:

    private:
        char nazwisko[25];
        string imie;
        Tdata dataur;

};

#endif // TOSOBA_H
